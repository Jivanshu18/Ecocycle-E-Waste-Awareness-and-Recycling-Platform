const mongoose=require('mongoose')
const schema=mongoose.Schema
const adminmodels=new schema({
    category:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    pname:{
        type:String,
        required:true
    },
    pdis:{
        type:String,
        required:true
    },
    price:{
        type:String,
        required:true
    }
})
const Adminmdls=mongoose.model('Adminmdls',adminmodels)
module.exports=Adminmdls
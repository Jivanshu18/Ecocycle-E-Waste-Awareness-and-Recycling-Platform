const express = require('express')
const router = express.Router()
const Users = require('../SchmaModels/schmdls')
const CreateError = require('http-errors')
const { authschema, loginschema } = require('./joivalidation')
const { signAccesstoken, verifyaccesstoken } = require('./jwttokengen')
const Mycart = require('../SchmaModels/CartSchema')
const Adminmdls = require('../SchmaModels/Adminmodels')

router.post('/register', async (req, res, next) => {
    try {
        const result = await authschema.validateAsync(req.body)
        const doexist = await Users.findOne({ email: result.email })
        if (doexist) throw CreateError.Conflict("Email already exist")
        if (result.password != result.cpassword) throw CreateError.Conflict(`Passwords are not matching`)
        const user = new Users(result)
        const saveduser = await user.save()
        const accessToken = await signAccesstoken(saveduser.id)
        res.send({ accessToken })

    }
    catch (error) {
        res.send(error)
        next(error)
    }
})
router.post('/userid',async(req,res,next)=>{
    await Users.findById(req.body.id)
   
    .then((result)=>{
        // console.log(result)
        res.send(result)})
})
router.post('/login', async (req, res, next) => {
    try {
        const result = await loginschema.validateAsync(req.body)
        const user = await Users.findOne({ email: result.email })
        if (!user) throw CreateError.Conflict("email or password is wrong")
        const domatch = await user.isValidPassword(result.password)
        if (!domatch) throw CreateError.Conflict("id or password is wrong")
        const accessToken = await signAccesstoken(user.id)
        res.send({ accessToken })
    }
    catch (error) {
        res.send(error)
        next(error)

    }
})
router.post('/cartitems', async (req, res, next) => {
    try {   
        const product = await Mycart.findOne({ pname: req.body.pname, email: req.body.email })
        if (product) {
            await Mycart.findByIdAndDelete(product.id)
        }
            const newproduct = new Mycart(req.body)
            const savedproduct = await newproduct.save()
            res.send(savedproduct)
        
    }
    catch (error) {
        // res.send(error)
        next(error)

    }
})
router.get('/private', verifyaccesstoken, async (req, res, next) => {
    res.send("this is private page")
})
router.post('/cart', async (req, res, next) => {
    await Mycart.find({email:req.body.email})
    .then((result)=>{
        console.log(result)
        res.send(result)
    })
})
router.post('/cartrem', async (req, res, next) => {

    const product = await Mycart.findOne({ pname: req.body.pname, email: req.body.email })
    if(product){await Mycart.findByIdAndDelete(product.id)
    .then((result)=>{res.send(result)})}
})
router.get('/allproducts',async(req,res,next)=>{
    try{
        await Adminmdls.find().then((response)=>{
            res.send(response)
        })
    }
    catch(error){
        next(error)
    }

    }
)
router.post('/allproductsbycategory',async(req,res,next)=>{
    try{
        await Adminmdls.find({category:req.body.category}).then((response)=>{
            res.send(response)
        })
    }
    catch(error){
        next(error)
    }

    }
)

module.exports = router
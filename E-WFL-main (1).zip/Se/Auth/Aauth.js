const express = require('express')
const rover = express.Router()
const Admins = require('../SchmaModels/Adscmodels')
const Adminmdls = require('../SchmaModels/Adminmodels')
const CreateError = require('http-errors')
const { authschema, loginschema } = require('./joivalidation')
const { signAccesstoken, verifyaccesstoken } = require('./jwttokengen')

rover.post('/register', async (req, res, next) => {
    try {
        const result = await authschema.validateAsync(req.body)
        const user = await Admins.findOne({ email: result.email })
        if (user) throw CreateError.Conflict('user alredy present')
        if (result.password != result.cpassword) throw CreateError.Conflict('password are not matching')
        const newAdmin = new Admins(result)
        const savedAdmin = await newAdmin.save()
        const accessToken = await signAccesstoken(savedAdmin.id)
        res.send({ accessToken })
    }
    catch (error) {
        res.send(error)
        next(error)
    }

})
rover.post('/login', async (req, res, next) => {
    try {
        const result = await loginschema.validateAsync(req.body)
        const user = await Admins.findOne({ email: result.email })
        if (!user) throw CreateError.Conflict('Something wrong with user')
        const domatch = await user.isValidPassword(result.password)
        if (!domatch) throw CreateError.Conflict('User id or password is wrong')
        const accessToken = await signAccesstoken(user.id)
        res.send({ accessToken })
    }
    catch (error) {
        res.send(error)
        next(error)
    }

})
rover.post('/adminmodels', async (req, res, next) => {

    const adminmodels = new Adminmdls(req.body)
    adminmodels.save()
    .then((result)=>{res.send(result)})
    
})
rover.post('/username', async (req, res, next) => {
    try {
        const user = await Admins.findById(req.body.aud)
        // console.log(req.body.aud)
        res.send(user)
    }
    catch (error) {
        res.send(error)
        next(error)
    }
})
rover.post('/adminmdata', async (req, res, next) => {
    try {
        console.log(req.body.email)
        await Adminmdls.find({ email: req.body.email })
        .then((result)=>{
            console.log(result)
        res.send(result)
        })
        
    }
    catch (error) {
        res.send(error)
        next(error)
    }
})
rover.get('/private', verifyaccesstoken, async (req, res, next) => {
    res.send("this is private page")
})
rover.get('/adminproduct', verifyaccesstoken, async (req, res, next) => {
    res.send("this is Admin product page")
})
module.exports = rover
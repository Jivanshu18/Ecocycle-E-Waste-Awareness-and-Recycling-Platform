const Joi = require('@hapi/joi')

const authschema = Joi.object({
    name: Joi.string().alphanum().min(3).max(30).required(),
    // gender: Joi.string().optional(),
    email: Joi.string().email().lowercase().required(),
    password: Joi.string().min(4).required(),
    cpassword: Joi.string().min(4).required(),
})
const loginschema=Joi.object({
    email: Joi.string().email().lowercase().required(),
    password: Joi.string().min(4).required(),
})

module.exports = { authschema, loginschema }

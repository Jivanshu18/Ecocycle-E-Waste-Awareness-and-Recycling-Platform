const JWT = require('jsonwebtoken')
const CreateError = require('http-errors')

module.exports = {
    signAccesstoken: (userId) => {
        return new Promise((resolve, reject) => {
            const payload = {}
            const secret = process.env.ACCESS_TOKEN_SECRET
            const options = {
                expiresIn: '2m',
                issuer: 'google.com',
                audience: userId
            }
            JWT.sign(payload, secret, options, (err, token) => {
                if (err)
                    reject(err)
                resolve(token)
                
            })
        })
    },
    verifyaccesstoken: (req, res, next) => {
        if (!req.headers['authorization']) return next(CreateError.Unauthorized())
        let bearerToken = req.headers["authorization"].split(' ')[1]
        JWT.verify(bearerToken, process.env.ACCESS_TOKEN_SECRET, (err, payload) => {
            if (err) return next(CreateError.Unauthorized())
            req.payload = payload
            next()
        })
    }

}
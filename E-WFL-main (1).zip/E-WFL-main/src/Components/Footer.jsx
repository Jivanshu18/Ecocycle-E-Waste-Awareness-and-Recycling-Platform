import React from "react";
import Logo from "../assets/echakra.png";

const Footer = () => {
  return (
    <div>
      <div class="h-fit w-full mt-[20vh] md:flex flex-col justify-center shadow-3xl  p-5">
        <div>
          <h1 class="font-semibold font-montserrat text-xl text-[#FEFBE5] text-left">
            You can help <br /> Shape the Future
          </h1>
        </div>

        <div class="mt-5 md:flex justify-between items-center">
          <div class="flex gap-2 ">
            <img src={Logo} alt="logo" class="h-[15vh]" />
          </div>

          <div>
            <ul class="flex gap-2">
              <li
                class="font-semibold font-montserrat  hover:text-[#ff5757] cursor-pointer"
                onClick={() => navigate("/")}
              >
                <a>Home |</a>
              </li>
              <li
                class="font-semibold font-montserrat  hover:text-[#ff5757] cursor-pointer"
                onClick={() =>
                  document
                    .getElementById("about")
                    .scrollIntoView({ behavior: "smooth" })
                }
              >
                <a>About |</a>
              </li>
              <li
                class="font-semibold font-montserrat hover:text-[#ff5757] cursor-pointer"
                onClick={() =>
                  document
                    .getElementById("contact")
                    .scrollIntoView({ behavior: "smooth" })
                }
              >
                <a>Education |</a>
              </li>
              <li
                class="font-semibold font-montserrat hover:text-[#ff5757] cursor-pointer"
                onClick={() =>
                  document
                    .getElementById("contact")
                    .scrollIntoView({ behavior: "smooth" })
                }
              >
                <a>Contact</a>
              </li>
            </ul>
          </div>
        </div>
        <div class="flex  items-center justify-center mt-5">
          <h1 class="flex justify-center text-xl text-left   font-montserrat font-semibold gap-2">
            Created by
            <span class="font-bold text-xl  font-montserrat text-[#ff5757]">
              EcoCycle
            </span>
            team
          </h1>
        </div>
      </div>
    </div>
  );
};

export default Footer;

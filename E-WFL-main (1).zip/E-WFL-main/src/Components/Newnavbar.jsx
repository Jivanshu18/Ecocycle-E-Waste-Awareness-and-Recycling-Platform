import React from "react";
import Wrapper from "./Wrapper";
import Logo from "../assets/echakra.png";
import { CiSearch } from "react-icons/ci";
import { AiOutlineHeart } from "react-icons/ai";
import Authdata from "../AuthService";
import { BsHandbag } from "react-icons/bs";

const Newnavbar = () => {
  const [currentUser, setCurrentUser] = useState(null);
  useEffect(() => {
    const user = Authdata.getuserdata();

    if (user) {
      setCurrentUser(user);
    }
  }, []);
  const logOut = () => {
    Authdata.logout();
    navigate("/login");
    window.location.reload(); // reload the page after logging out so that it updates state and
  };
  return (
    <div class="min-h-[13vh] flex items-center border-b-2 ">
      <Wrapper>
        <Wrapper>
          <div class="flex items-center justify-between">
            {/* Logo */}

            <div class="flex gap-2 ">
              <img src={Logo} alt="logo" class="h-[15vh]" />
            </div>

            {/* Search */}

            <div class="bg-gray-200 w-[40vw] items-center gap-2 flex px-4 py-3 rounded-2xl min-h-[5vh]">
              <CiSearch />
              <input
                type="text"
                class="bg-gray-200 font-poppins focus:border-none focus:outline-none"
                placeholder="Search"
              />
            </div>

            {/* Buttons */}

            <div class="flex gap-4">
              {!currentUser ? (
                <button
                  class="shadow-3xl font-medium border-2 font-poppins px-4 py-2 bg-[#222222] rounded-md hover:bg-[#01796f]  transition-transform nav"
                  onClick={() => {
                    setislogin(true);
                    navigate("/login");
                  }}
                >
                  Login
                </button>
              ) : (
                <button
                  class="shadow-3xl font-medium border-2 font-poppins px-4 py-2 bg-[#222222] rounded-md hover:bg-[#01796f]  transition-transform nav"
                  onClick={logOut}
                >
                  Logout
                </button>
              )}
              <div class="flex items-center text-xl gap-4">
                <button>
                  <AiOutlineHeart />
                </button>
                <button>
                  <BsHandbag />
                </button>
              </div>
            </div>

            {/* Icons */}
          </div>
        </Wrapper>
      </Wrapper>
    </div>
  );
};

export default Newnavbar;

import React from "react";
import Wrapper from "./Wrapper";

const Contact = () => {
  return (
    <div id="contact">
      <div class="flex flex-col  justify-center items-center mt-[20vh]">
        <h1 class="mb-[10vh] font-montserrat font-bold text-2xl">
          Contact Us
        </h1>
        <div class="w-fit h-fit bg-[#343434] shadow-3xl rounded-xl  p-[5vh] md:ml-5 mb-10 z-10 searchtext card">
          <h1 class="md:text-[5vh] text-[8vh] font-montserrat  font-bold">
            Contact our Team
          </h1>
          

          <div class="mt-10 flex flex-col gap-5">
            <div class="md:flex  md:gap-5">
              <div class="relative">
                <p class="font-montserrat font-semibold ">
                  Email
                </p>
                <h3>balodiah7@gmail.com</h3>
              </div>
              {/* Dropdown state */}
              <div class="relative">
                <p class="font-poppins font-semibold md:mt-0 mt-5 ">
                  tel
                </p>
                <h3>+91 xxxxxxxxxx</h3>
              </div>
            </div>
            <div class="relative">
                <p class="font-poppins font-semibold md:mt-0 mt-5 ">
                  fax 
                </p>
                <h3> xxxxxxxxxx</h3>
              </div>
            <button
              class="hover:bg-[#01796f] mt-[2vh] hover:scale-105 shadow-3xl transition-transform  font-montserrat font-semibold p-4 rounded-lg  w-fit"
              onClick={() => register()}
            >
              Submit
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;

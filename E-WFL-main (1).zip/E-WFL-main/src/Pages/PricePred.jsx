import React from 'react'

const PricePred = () => {
  return (
    <div>PricePred</div>
  )
}

export default PricePred
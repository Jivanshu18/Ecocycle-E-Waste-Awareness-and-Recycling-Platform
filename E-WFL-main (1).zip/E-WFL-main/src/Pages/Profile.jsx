import React from 'react'
import { Wrapper } from '../Components'
import { useContext } from 'react'
import Context from '../context/Context'
import { useNavigate } from 'react-router-dom'
import admin from "../assets/profile.png";
import profile from "../assets/man.png"
import { useEffect } from 'react'

const Profile = () => {

    const {User} = useContext(Context);

    const navigate = useNavigate();

    const logout = () => {
        sessionStorage.removeItem("user");
        navigate("/")
    }

    useEffect(() => {
        
        console.log(User)

    }, [])

  return (
    <Wrapper>
    <div class='flex justify-center  my-[10vh] md:mx-0 mx-[5vw]'>
        <div class='h-fit w-fit shadow-3xl flex flex-col md:flex-row gap-[10vh] justify-center items-center px-10 py-10'>
            
            <div class='shadow-3xl w-fit p-4 rounded-lg'>
            {User?.isadmin ? (<img src={admin} alt="" class='h-[20vh] md:h-[30vh]' />) : (<img src={profile} alt="" class='h-[20vh] md:h-[30vh]' />)}
                
            </div>
            <div class='flex flex-col gap-5 '>
                <div class='flex flex-col gap-5 mb-5 '>
                <div class='flex gap-5'>
                    <h2 class='text-xl text-[#F9F6EE] font-poppins font-semibold'>Profile </h2>
                    {User?.role ==  "admin"? (<h2 class='text-xl font-poppins font-medium text-[#F9F6EE]'>Admin</h2>) : (<h2 class='text-xl text-[#F9F6EE] font-poppins font-medium'>User</h2>)}
                    
                </div>
                <div class='flex gap-5'>
                    <h2 class='text-xl text-[#F9F6EE] font-poppins font-semibold'>Name </h2>
                    <h2 class='text-xl text-[#F9F6EE] font-poppins font-medium'>{User?.username}</h2>
                </div>
                <div class='flex gap-5'>
                    <h2 class='text-xl text-[#F9F6EE] font-poppins font-semibold'>Email </h2>
                    <h2 class='text-xl text-[#F9F6EE] font-poppins font-medium'>{User?.email}</h2>
                </div>
                <div class='flex gap-5'>
                    <h2 class='text-xl text-[#F9F6EE] font-poppins font-semibold'>Credit Points </h2>
                    <h2 class='text-xl text-[#F9F6EE] font-poppins font-medium'>{User?.creditPoints}</h2>
                </div>
                <div class='flex gap-5'>
                    <h2 class='text-xl text-[#F9F6EE] font-poppins font-semibold'>Recycled Items </h2>
                    <h2 class='text-xl text-[#F9F6EE] font-poppins font-medium'>{User?.recycledDevices?.length}</h2>
                </div>
                </div>
                <button
              class="shadow-3xl font-medium border-2 font-poppins px-4 py-2 bg-[#222222] rounded-md hover:bg-[#01796f]  transition-transform nav"
              onClick={() => logout()}
            >
              Logout
            </button>
            </div>
            
        </div>
    </div>
    </Wrapper>
  )
}

export default Profile
import React, { useEffect, useState } from "react";
import mapboxgl, { Marker } from "mapbox-gl";
import polyline from "@mapbox/polyline";
import { useContext } from "react";
import Context from "../context/Context";
import { Wrapper, Facilites } from "../Components";
import { useParams } from "react-router-dom";

const SearchMap = () => {
  const { Location, Locationstate, facdata, fetcheddata } = useContext(Context);
  const [map, setmap] = useState(null);
  const [coordinates, setCoordinates] = useState([]);
  const [marker, setmarker] = useState(null);
  const [searchaddress, setsearchaddress] = useState("");
  const [initaddress, setinitaddress] = useState("");
  const [nearestLocations, setNearestLocations] = useState([]);

  const initializeMap = (coordinates1) => {
    mapboxgl.accessToken =
      "pk.eyJ1IjoibmlzaGFudDc0MTIiLCJhIjoiY2xtYm42NHI5MWN0ZTNkbzVsdzhkNnl0bSJ9.FXHqQifsNwqwWW3g4qEZgw";

    const map = new mapboxgl.Map({
      container: "map",
      style: "mapbox://styles/nishant7412/clmd5l4yi01bz01r71roa6h2m",
      zoom: 18,
      pitch: 50,
      bearing: 0,
    });

    return map;
  };

  const Geocodeaddress = async (address) => {
    console.log(address);
    mapboxgl.accessToken =
      "pk.eyJ1IjoibmlzaGFudDc0MTIiLCJhIjoiY2xtYm42NHI5MWN0ZTNkbzVsdzhkNnl0bSJ9.FXHqQifsNwqwWW3g4qEZgw";
    const geocodingApiUrl = `https://api.mapbox.com/geocoding/v5/mapbox.places/${address}.json?access_token=${mapboxgl.accessToken}`;
    const response = await fetch(geocodingApiUrl);
    const data = await response.json();

    const coordinates = data.features[0].center;

    console.log(coordinates);

    return coordinates;
  };

  const locations = [
    {
      name: "Hindustan e waste management pvt ltd",
      coordinates: [77.24932062123997, 28.58357208482082],
      capacity: 1000,
    },
    {
      name: "Greenzone ewaste recycler",
      coordinates: [77.25277135048263, 28.549784116196772],
      capacity: 1000,
    },
    {
      name: "E - waste Recyclers India Network",
      coordinates: [77.25138819969365, 28.55202528543071],
      capacity: 1000,
    },
    {
      name: "Resource E waste solution pvt ltd",
      coordinates: [77.31266412154562, 28.64115175688466],
      capacity: 1000,
    },
    {
      name: "E Waste Recycle Hub",
      coordinates: [77.15945238261948, 28.70003018777286],
      capacity: 1000,
    },
    {
      name: "GREEN TECH",
      coordinates: [88.35737082523322, 22.557118651974562],
      capacity: 1000,
    },
    {
      name: "Indian Scrap Organization",
      coordinates: [88.35508102097454, 22.560841265120146],
      capacity: 1000,
    },
    {
      name: "Vital Waste",
      coordinates: [88.35139077838883, 22.53643650924637],
      capacity: 1000,
    },
    {
      name: "E-Waste Bazaar",
      coordinates: [88.35566316330267, 22.556705689841596],
      capacity: 1000,
    },
    {
      name: "Green Life E-Waste Recycling- E-Waste Management | Battery Recycling Solutions | Electronic Waste India",
      coordinates: [72.88055355153757, 19.07243144008707],
      capacity: 1000,
    },
    {
      name: "BEST RECYCLING COMPANY IN MUMBAI,E-WASTE SCRAP BUYERS IN MUMBAI,COMPUTER SCRAP BUYERS MUMBAI,E-WASTE RECYCLING COMPANY MUMBAI",
      coordinates: [72.83128560921116, 19.131934834504605],
      capacity: 1000,
    },
    {
      name: "E-Waste Mart - Electronic Waste Recycling Company in Mumbai, India",
      coordinates: [72.88766936248082, 19.0984861989275],
      capacity: 1000,
    },
    {
      name: "Ecostar Recycling - E Waste Recycling Mumbai, Recycling Centre",
      coordinates: [72.87102277852254, 19.07639583718735],
      capacity: 1000,
    },
  ];

  const handleSearchCity = async () => {
    try {
      if (marker) {
        marker.remove();
      }

      const distances = locations.map((location) => {
        const [lng, lat] = location.coordinates;
        return {
          name: location.name,
          coordinates: location.coordinates,
          distance: Math.sqrt(
            Math.pow(lng - coordinates[0], 2) +
              Math.pow(lat - coordinates[1], 2)
          ),
        };
      });

      const nearestLocations = distances
        .sort((a, b) => a.distance - b.distance)
        .slice(0, 5);

      setNearestLocations(nearestLocations);

      const markers = nearestLocations.map((loc) => {
        return new mapboxgl.Marker({ color: "red" })
          .setLngLat(loc.coordinates)
          .setPopup(new mapboxgl.Popup().setText(loc.name))
          .addTo(map);
      });

      const bounds = new mapboxgl.LngLatBounds();
      nearestLocations.forEach((loc) => {
        bounds.extend(loc.coordinates);
      });

      map.fitBounds(bounds, {
        padding: 50,
        duration: 1000,
      });
    } catch (error) {
      console.error("Error:", error);
    }
  };

  const SetAddressMarker = (Location) => {
    const addressToGeocode = decodeURIComponent(Location);
    console.log(
      Location.length > 100 ? address.slice(0, 100).length : Location.length
    );

    Geocodeaddress(Location.length > 120 ? Location.slice(0, 120) : Location)
      .then((initialCoordinates) => {
        setCoordinates(initialCoordinates);
        const map1 = initializeMap();
        map1.setCenter(initialCoordinates);
        setmap(map1);

        new mapboxgl.Marker().setLngLat(initialCoordinates).addTo(map1);
        new mapboxgl.Popup()
          .setLngLat(initialCoordinates)
          .setHTML(
            `
         <div style="background-color: #ffffff; padding: 10px; border: 1px solid #ccc; border-radius: 5px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
         <p style="color: black; font-size: 14px; font: montserrat, font-weight: bold">${addressToGeocode}</p>
         </div>
                 `
          )
          .addTo(map1);
      })
      .catch((error) => {
        console.error("Error:", error);
      });

    return () => {
      mapboxgl.accessToken = null;
    };
  };

  const handleSearch = () => {
    SetAddressMarker(searchaddress ? searchaddress : null);
  };

  useEffect(() => {
    SetAddressMarker(Location ? Location : "Bhopal");
  }, []);

  return (
    <Wrapper>
      <div className="relative mt-[2vh]">
        <div id="map" className="h-[70vh] w-full rounded-xl" />
        <div className="absolute top-0 flex gap-[1vh] justify-between items-center p-4">
          <input
            type="text"
            className="w-full mt-2 mx-[2vh] rounded-lg text-[#F9F6EE] p-4 font-montserrat border-2 font-medium bg-[#222222]"
            onChange={(e) => {
              setsearchaddress(e.target.value);
            }}
            placeholder="Enter Your Location"
          />
          <button
            className="hover:bg-[#ff5757] h-fit mt-2 hover:scale-105 shadow-3xl transition-transform  font-montserrat font-semibold p-4 rounded-lg  w-fit"
            onClick={handleSearch}
          >
            Search
          </button>
          <button
            className="hover:bg-[#ff5757] h-fit mt-2 hover:scale-105 shadow-3xl transition-transform  font-montserrat font-semibold p-4 rounded-lg  w-fit"
            onClick={handleSearchCity}
          >
            Show Nearest Locations
          </button>
        </div>
      </div>

      <div className="nearest-locations mt-5 p-4">
        <h2 className="font-montserrat text-lg font-semibold mb-4">
          Nearest Locations:
        </h2>
        <ul className="list-disc pl-5">
          {nearestLocations.map((location, index) => (
            <li key={index} className="font-montserrat text-base mb-2">
              {location.name}
            </li>
          ))}
        </ul>
      </div>
    </Wrapper>
  );
};

export default SearchMap;

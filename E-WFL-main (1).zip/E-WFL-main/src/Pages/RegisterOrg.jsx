import React from 'react'

const RegisterOrg = () => {
  return (
    <div>RegisterOrg</div>
  )
}

export default RegisterOrg